This is a stripped-down version of the "LowPoly Vegetation Season Pack".
It includes:
23 prefab.
2 textures .PSD which you can easily edit at your discretion.


You can purchase the full version of the pack from the link below.
https://assetstore.unity.com/packages/3d/vegetation/lowpoly-vegetation-season-pack-90671

The full version of the pack includes 392 different models:
DesertTree x9
Tree x59
FirTree x19
DestroyedTree x11
DeatTree x40
Palm x27
Shrub x23
Stump x15
Bambuk x4
Cactus x9
Wood and Branch x15
Vine x9
Grass x37
Flower x24
Leaf x 6
Fruits x13
Vegetables x13

Bonus:
Modular Terrain x20
Stone x4
Cloud x4
Fence x8
Gate x2
Backet
Chair
Tablet
Bench
